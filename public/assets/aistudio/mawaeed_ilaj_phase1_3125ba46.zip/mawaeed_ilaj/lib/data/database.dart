import 'dart:io';

import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

import '../models/models.dart';

class AppDatabase {
  AppDatabase._();
  static final instance = AppDatabase._();

  Database? _db;
  Future<Database> get _database async => _db ??= await _open();

  Future<Database> _open() async {
    final path = p.join(await getDatabasesPath(), 'mawaeed.db');
    return openDatabase(
      path,
      version: 1,
      onConfigure: (d) => d.execute('PRAGMA foreign_keys = ON'),
      onCreate: (d, _) async {
        await d.execute('''
          CREATE TABLE profiles(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            relation TEXT NOT NULL DEFAULT 'self'
          )''');
        await d.execute('''
          CREATE TABLE appointments(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            profile_id INTEGER NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
            title TEXT NOT NULL,
            doctor TEXT,
            date_time INTEGER NOT NULL,
            location_text TEXT,
            lat REAL,
            lng REAL,
            notes TEXT,
            repeat TEXT NOT NULL DEFAULT 'none',
            reminder_offsets TEXT NOT NULL DEFAULT '1440,60'
          )''');
        await d.execute(
            'CREATE INDEX idx_appt_profile_time ON appointments(profile_id, date_time)');
        await d.execute('''
          CREATE TABLE medications(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            profile_id INTEGER NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
            name TEXT NOT NULL,
            dose TEXT,
            times TEXT NOT NULL,
            start_date INTEGER NOT NULL,
            end_date INTEGER
          )''');
        await d.execute('''
          CREATE TABLE attachments(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            owner_type TEXT NOT NULL,
            owner_id INTEGER NOT NULL,
            path TEXT NOT NULL,
            kind TEXT NOT NULL,
            created_at INTEGER NOT NULL
          )''');
        await d.execute(
            'CREATE INDEX idx_attach_owner ON attachments(owner_type, owner_id)');
        // البروفايل الافتراضي
        await d.insert('profiles', {'name': 'أنا', 'relation': 'self'});
      },
    );
  }

  // ---------- Profiles ----------
  Future<List<Profile>> profiles() async {
    final d = await _database;
    return (await d.query('profiles', orderBy: 'id'))
        .map(Profile.fromMap)
        .toList();
  }

  Future<Map<int, String>> profileNames() async {
    final all = await profiles();
    return {for (final p in all) p.id!: p.name};
  }

  Future<int> insertProfile(Profile p) async =>
      (await _database).insert('profiles', p.toMap());

  // ---------- Appointments ----------
  Future<List<Appointment>> appointmentsFor(int profileId) async {
    final d = await _database;
    final rows = await d.query('appointments',
        where: 'profile_id = ?', whereArgs: [profileId], orderBy: 'date_time');
    return rows.map(Appointment.fromMap).toList();
  }

  Future<List<Appointment>> allAppointments() async {
    final d = await _database;
    return (await d.query('appointments')).map(Appointment.fromMap).toList();
  }

  Future<int> insertAppointment(Appointment a) async =>
      (await _database).insert('appointments', a.toMap());

  Future<void> updateAppointment(Appointment a) async => (await _database)
      .update('appointments', a.toMap(), where: 'id = ?', whereArgs: [a.id]);

  Future<void> deleteAppointment(int id) async {
    final d = await _database;
    await _deleteOwnerAttachments(d, OwnerType.appointment, id);
    await d.delete('appointments', where: 'id = ?', whereArgs: [id]);
  }

  // ---------- Medications ----------
  Future<List<Medication>> medicationsFor(int profileId) async {
    final d = await _database;
    final rows = await d.query('medications',
        where: 'profile_id = ?', whereArgs: [profileId], orderBy: 'name');
    return rows.map(Medication.fromMap).toList();
  }

  Future<List<Medication>> allMedications() async {
    final d = await _database;
    return (await d.query('medications')).map(Medication.fromMap).toList();
  }

  Future<int> insertMedication(Medication m) async =>
      (await _database).insert('medications', m.toMap());

  Future<void> updateMedication(Medication m) async => (await _database)
      .update('medications', m.toMap(), where: 'id = ?', whereArgs: [m.id]);

  Future<void> deleteMedication(int id) async {
    final d = await _database;
    await _deleteOwnerAttachments(d, OwnerType.medication, id);
    await d.delete('medications', where: 'id = ?', whereArgs: [id]);
  }

  // ---------- Attachments ----------
  Future<List<Attachment>> attachmentsFor(OwnerType type, int ownerId) async {
    final d = await _database;
    final rows = await d.query('attachments',
        where: 'owner_type = ? AND owner_id = ?',
        whereArgs: [type.name, ownerId],
        orderBy: 'created_at DESC');
    return rows.map(Attachment.fromMap).toList();
  }

  Future<int> insertAttachment(Attachment a) async =>
      (await _database).insert('attachments', a.toMap());

  Future<void> deleteAttachment(Attachment a) async {
    final d = await _database;
    final f = File(a.path);
    if (await f.exists()) await f.delete();
    await d.delete('attachments', where: 'id = ?', whereArgs: [a.id]);
  }

  Future<void> _deleteOwnerAttachments(
      Database d, OwnerType type, int ownerId) async {
    final rows = await d.query('attachments',
        where: 'owner_type = ? AND owner_id = ?',
        whereArgs: [type.name, ownerId]);
    for (final r in rows) {
      final f = File(r['path'] as String);
      if (await f.exists()) await f.delete();
    }
    await d.delete('attachments',
        where: 'owner_type = ? AND owner_id = ?',
        whereArgs: [type.name, ownerId]);
  }
}
