enum RepeatRule { none, daily, weekly, monthly }

enum AttachmentKind { report, test, prescription, other }

enum OwnerType { appointment, medication }

T _enumByName<T extends Enum>(List<T> values, String? name, T fallback) {
  for (final v in values) {
    if (v.name == name) return v;
  }
  return fallback;
}

/// شخص داخل التطبيق: أنا، أمي، ابني...
class Profile {
  final int? id;
  final String name;
  final String relation;

  const Profile({this.id, required this.name, this.relation = 'self'});

  Map<String, Object?> toMap() => {
        if (id != null) 'id': id,
        'name': name,
        'relation': relation,
      };

  factory Profile.fromMap(Map<String, Object?> m) => Profile(
        id: m['id'] as int,
        name: m['name'] as String,
        relation: m['relation'] as String,
      );
}

class Appointment {
  final int? id;
  final int profileId;
  final String title;
  final String? doctor;
  final DateTime dateTime;
  final String? locationText;
  final double? lat;
  final double? lng;
  final String? notes;
  final RepeatRule repeat;

  /// قبل الموعد بكام دقيقة نبعت تذكير (الحد الأقصى 10 تذكيرات).
  final List<int> reminderOffsetsMinutes;

  const Appointment({
    this.id,
    required this.profileId,
    required this.title,
    this.doctor,
    required this.dateTime,
    this.locationText,
    this.lat,
    this.lng,
    this.notes,
    this.repeat = RepeatRule.none,
    this.reminderOffsetsMinutes = const [1440, 60],
  });

  bool get hasLocation =>
      (lat != null && lng != null) ||
      (locationText != null && locationText!.trim().isNotEmpty);

  Map<String, Object?> toMap() => {
        if (id != null) 'id': id,
        'profile_id': profileId,
        'title': title,
        'doctor': doctor,
        'date_time': dateTime.millisecondsSinceEpoch,
        'location_text': locationText,
        'lat': lat,
        'lng': lng,
        'notes': notes,
        'repeat': repeat.name,
        'reminder_offsets': reminderOffsetsMinutes.join(','),
      };

  factory Appointment.fromMap(Map<String, Object?> m) => Appointment(
        id: m['id'] as int,
        profileId: m['profile_id'] as int,
        title: m['title'] as String,
        doctor: m['doctor'] as String?,
        dateTime: DateTime.fromMillisecondsSinceEpoch(m['date_time'] as int),
        locationText: m['location_text'] as String?,
        lat: (m['lat'] as num?)?.toDouble(),
        lng: (m['lng'] as num?)?.toDouble(),
        notes: m['notes'] as String?,
        repeat: _enumByName(
            RepeatRule.values, m['repeat'] as String?, RepeatRule.none),
        reminderOffsetsMinutes: (m['reminder_offsets'] as String)
            .split(',')
            .where((s) => s.trim().isNotEmpty)
            .map(int.parse)
            .toList(),
      );
}

/// وقت من اليوم (ساعة ودقيقة) بدون تاريخ.
class DayTime {
  final int hour;
  final int minute;
  const DayTime(this.hour, this.minute);

  String encode() =>
      '${hour.toString().padLeft(2, '0')}:${minute.toString().padLeft(2, '0')}';

  factory DayTime.parse(String s) {
    final p = s.split(':');
    return DayTime(int.parse(p[0]), int.parse(p[1]));
  }
}

class Medication {
  final int? id;
  final int profileId;
  final String name;
  final String? dose;
  final List<DayTime> times; // مواعيد الجرعات في اليوم (حد أقصى 10)
  final DateTime startDate;
  final DateTime? endDate;

  const Medication({
    this.id,
    required this.profileId,
    required this.name,
    this.dose,
    required this.times,
    required this.startDate,
    this.endDate,
  });

  Map<String, Object?> toMap() => {
        if (id != null) 'id': id,
        'profile_id': profileId,
        'name': name,
        'dose': dose,
        'times': times.map((t) => t.encode()).join(','),
        'start_date': startDate.millisecondsSinceEpoch,
        'end_date': endDate?.millisecondsSinceEpoch,
      };

  factory Medication.fromMap(Map<String, Object?> m) => Medication(
        id: m['id'] as int,
        profileId: m['profile_id'] as int,
        name: m['name'] as String,
        dose: m['dose'] as String?,
        times: (m['times'] as String)
            .split(',')
            .where((s) => s.trim().isNotEmpty)
            .map(DayTime.parse)
            .toList(),
        startDate: DateTime.fromMillisecondsSinceEpoch(m['start_date'] as int),
        endDate: m['end_date'] == null
            ? null
            : DateTime.fromMillisecondsSinceEpoch(m['end_date'] as int),
      );
}

class Attachment {
  final int? id;
  final OwnerType ownerType;
  final int ownerId;
  final String path;
  final AttachmentKind kind;
  final DateTime createdAt;

  const Attachment({
    this.id,
    required this.ownerType,
    required this.ownerId,
    required this.path,
    required this.kind,
    required this.createdAt,
  });

  Map<String, Object?> toMap() => {
        if (id != null) 'id': id,
        'owner_type': ownerType.name,
        'owner_id': ownerId,
        'path': path,
        'kind': kind.name,
        'created_at': createdAt.millisecondsSinceEpoch,
      };

  factory Attachment.fromMap(Map<String, Object?> m) => Attachment(
        id: m['id'] as int,
        ownerType: _enumByName(
            OwnerType.values, m['owner_type'] as String?, OwnerType.appointment),
        ownerId: m['owner_id'] as int,
        path: m['path'] as String,
        kind: _enumByName(
            AttachmentKind.values, m['kind'] as String?, AttachmentKind.other),
        createdAt: DateTime.fromMillisecondsSinceEpoch(m['created_at'] as int),
      );
}
