import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/date_symbol_data_local.dart';

import 'data/database.dart';
import 'screens/home_screen.dart';
import 'services/notification_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await initializeDateFormatting('ar');
  await NotificationService.instance.init();
  // للتبسيط دلوقتي؛ الأفضل تنقل طلب الصلاحيات لشاشة ترحيب.
  // Permissions should be requested through an explicit user action.
  await NotificationService.instance.rescheduleAll(AppDatabase.instance);
  runApp(const ProviderScope(child: MawaeedApp()));
}

class MawaeedApp extends StatelessWidget {
  const MawaeedApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'مواعيد العلاج',
      debugShowCheckedModeBanner: false,
      locale: const Locale('ar'),
      supportedLocales: const [Locale('ar')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.teal),
      home: const HomeScreen(),
    );
  }
}
