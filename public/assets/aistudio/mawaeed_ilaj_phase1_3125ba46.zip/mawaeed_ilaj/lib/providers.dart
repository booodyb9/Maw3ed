import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'data/database.dart';
import 'models/models.dart';

final profilesProvider =
    FutureProvider<List<Profile>>((ref) => AppDatabase.instance.profiles());

/// null = أول بروفايل (الافتراضي "أنا").
final currentProfileIdProvider = StateProvider<int?>((ref) => null);

final appointmentsProvider = FutureProvider<List<Appointment>>((ref) async {
  final profiles = await ref.watch(profilesProvider.future);
  final id = ref.watch(currentProfileIdProvider) ?? (profiles.isEmpty ? -1 : profiles.first.id!);
  return AppDatabase.instance.appointmentsFor(id);
});

final medicationsProvider = FutureProvider<List<Medication>>((ref) async {
  final profiles = await ref.watch(profilesProvider.future);
  final id = ref.watch(currentProfileIdProvider) ?? (profiles.isEmpty ? -1 : profiles.first.id!);
  return AppDatabase.instance.medicationsFor(id);
});
