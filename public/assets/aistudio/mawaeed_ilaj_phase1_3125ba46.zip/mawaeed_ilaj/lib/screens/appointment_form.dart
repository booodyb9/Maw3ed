import 'package:flutter/material.dart';
import '../data/database.dart';
import '../models/models.dart';
import '../services/notification_service.dart';

class AppointmentForm extends StatefulWidget {
  final int profileId;
  final Appointment? appointment;
  const AppointmentForm({super.key, required this.profileId, this.appointment});
  @override
  State<AppointmentForm> createState() => _AppointmentFormState();
}

class _AppointmentFormState extends State<AppointmentForm> {
  final _key = GlobalKey<FormState>();
  late final _title = TextEditingController(text: widget.appointment?.title ?? '');
  late final _doctor = TextEditingController(text: widget.appointment?.doctor ?? '');
  late final _location = TextEditingController(text: widget.appointment?.locationText ?? '');
  late final _notes = TextEditingController(text: widget.appointment?.notes ?? '');
  late DateTime _date = widget.appointment?.dateTime ?? DateTime.now().add(const Duration(days: 1));
  bool _busy = false;
  @override
  void dispose() { _title.dispose(); _doctor.dispose(); _location.dispose(); _notes.dispose(); super.dispose(); }
  Future<void> _pick() async {
    final day = await showDatePicker(context: context, initialDate: _date, firstDate: DateTime(2020), lastDate: DateTime(2100));
    if (day == null || !mounted) return;
    final time = await showTimePicker(context: context, initialTime: TimeOfDay.fromDateTime(_date));
    if (time == null || !mounted) return;
    setState(() => _date = DateTime(day.year, day.month, day.day, time.hour, time.minute));
  }
  Future<void> _save() async {
    if (!_key.currentState!.validate() || _busy) return;
    setState(() => _busy = true);
    try {
      final old = widget.appointment;
      final a = Appointment(id: old?.id, profileId: widget.profileId, title: _title.text.trim(), doctor: _doctor.text.trim(), dateTime: _date, locationText: _location.text.trim(), notes: _notes.text.trim(), repeat: old?.repeat ?? RepeatRule.none, reminderOffsetsMinutes: old?.reminderOffsetsMinutes ?? const [1440, 60]);
      final db = AppDatabase.instance;
      final id = old == null ? await db.insertAppointment(a) : old.id!;
      if (old != null) await db.updateAppointment(a);
      try {
        final names = await db.profileNames();
        await NotificationService.instance.scheduleAppointment(Appointment(id: id, profileId: a.profileId, title: a.title, doctor: a.doctor, dateTime: a.dateTime, locationText: a.locationText, notes: a.notes, repeat: a.repeat, reminderOffsetsMinutes: a.reminderOffsetsMinutes), names[a.profileId] ?? '');
      } catch (_) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم حفظ الموعد لكن تعذرت جدولة التنبيه. راجع أذونات الإشعارات.'))); }
      if (mounted) Navigator.pop(context, true);
    } catch (e) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تعذر الحفظ: $e'))); }
    finally { if (mounted) setState(() => _busy = false); }
  }
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(widget.appointment == null ? 'إضافة موعد' : 'تعديل موعد')),
    body: Form(key: _key, child: ListView(padding: const EdgeInsets.all(16), children: [
      TextFormField(controller: _title, decoration: const InputDecoration(labelText: 'عنوان الموعد *'), validator: (s) => s == null || s.trim().isEmpty ? 'اكتب عنوان الموعد' : null),
      TextFormField(controller: _doctor, decoration: const InputDecoration(labelText: 'الطبيب')),
      ListTile(title: const Text('التاريخ والوقت'), subtitle: Text('${_date.year}-${_date.month}-${_date.day}  ${TimeOfDay.fromDateTime(_date).format(context)}'), trailing: const Icon(Icons.event), onTap: _pick),
      TextFormField(controller: _location, decoration: const InputDecoration(labelText: 'المكان')),
      TextFormField(controller: _notes, decoration: const InputDecoration(labelText: 'ملاحظات'), maxLines: 3),
      const SizedBox(height: 20), FilledButton(onPressed: _busy ? null : _save, child: Text(_busy ? 'جارٍ الحفظ...' : 'حفظ الموعد')),
    ])),
  );
}
