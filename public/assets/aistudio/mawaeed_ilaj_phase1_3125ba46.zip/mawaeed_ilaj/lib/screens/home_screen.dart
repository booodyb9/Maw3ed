import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';

import '../providers.dart';
import '../data/database.dart';
import '../services/notification_service.dart';
import 'appointment_form.dart';
import '../services/map_launcher.dart';

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final profiles = ref.watch(profilesProvider);
    final appointments = ref.watch(appointmentsProvider);
    final currentId = ref.watch(currentProfileIdProvider);

    return Scaffold(
      appBar: AppBar(
        title: profiles.maybeWhen(
          data: (list) => list.isEmpty ? const Text('لا توجد ملفات شخصية') : DropdownButtonHideUnderline(
            child: DropdownButton<int>(
              value: currentId ?? list.first.id!,
              items: [
                for (final p in list)
                  DropdownMenuItem(value: p.id!, child: Text(p.name)),
              ],
              onChanged: (v) =>
                  ref.read(currentProfileIdProvider.notifier).state = v,
            ),
          ),
          orElse: () => const Text('مواعيد العلاج'),
        ),
      ),
      body: appointments.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text('حصل خطأ: $e')),
        data: (list) {
          if (list.isEmpty) {
            return const Center(child: Text('مفيش مواعيد لسه'));
          }
          return ListView.separated(
            padding: const EdgeInsets.all(12),
            itemCount: list.length,
            separatorBuilder: (_, __) => const SizedBox(height: 8),
            itemBuilder: (_, i) {
              final a = list[i];
              return Card(
                child: ListTile(
                  onTap: () async {
                    final saved = await Navigator.push<bool>(context, MaterialPageRoute(builder: (_) => AppointmentForm(profileId: a.profileId, appointment: a)));
                    if (saved == true) ref.invalidate(appointmentsProvider);
                  },
                  onLongPress: () async {
                    final yes = await showDialog<bool>(context: context, builder: (c) => AlertDialog(title: const Text('حذف الموعد؟'), content: Text(a.title), actions: [TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('إلغاء')), TextButton(onPressed: () => Navigator.pop(c, true), child: const Text('حذف'))]));
                    if (yes != true || a.id == null) return;
                    await AppDatabase.instance.deleteAppointment(a.id!);
                    try { await NotificationService.instance.cancelAppointment(a.id!); } catch (_) {}
                    ref.invalidate(appointmentsProvider);
                  },
                  title: Text(a.title),
                  subtitle: Text([
                    if (a.doctor != null && a.doctor!.isNotEmpty) a.doctor!,
                    DateFormat('EEEE d MMMM، h:mm a', 'ar').format(a.dateTime),
                  ].join('\n')),
                  isThreeLine: a.doctor != null && a.doctor!.isNotEmpty,
                  trailing: a.hasLocation
                      ? IconButton(
                          icon: const Icon(Icons.map_outlined),
                          onPressed: () => openInMaps(
                              lat: a.lat, lng: a.lng, query: a.locationText),
                        )
                      : null,
                ),
              );
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          final profiles = await ref.read(profilesProvider.future);
          if (profiles.isEmpty || !context.mounted) return;
          final id = ref.read(currentProfileIdProvider) ?? profiles.first.id!;
          final saved = await Navigator.push<bool>(context, MaterialPageRoute(builder: (_) => AppointmentForm(profileId: id)));
          if (saved == true) ref.invalidate(appointmentsProvider);
        },
        icon: const Icon(Icons.add),
        label: const Text('موعد جديد'),
      ),
    );
  }
}
