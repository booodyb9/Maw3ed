import 'package:url_launcher/url_launcher.dart';

/// يفتح المكان في تطبيق الخرائط (إحداثيات لو متاحة، وإلا بحث بالنص).
Future<bool> openInMaps({double? lat, double? lng, String? query}) async {
  final Uri uri;
  if (lat != null && lng != null) {
    uri = Uri.parse('https://www.google.com/maps/search/?api=1&query=$lat,$lng');
  } else if (query != null && query.trim().isNotEmpty) {
    uri = Uri.https(
        'www.google.com', '/maps/search/', {'api': '1', 'query': query.trim()});
  } else {
    return false;
  }
  return launchUrl(uri, mode: LaunchMode.externalApplication);
}
