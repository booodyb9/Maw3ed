import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

import '../data/database.dart';
import '../models/models.dart';

class AttachmentService {
  /// بيختار ملف، وينسخه جوه مجلد التطبيق الخاص (مش في المعرض)،
  /// وبعدين يسجله في قاعدة البيانات.
  static Future<Attachment?> pickAndStore({
    required OwnerType ownerType,
    required int ownerId,
    required AttachmentKind kind,
  }) async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: const ['pdf', 'jpg', 'jpeg', 'png'],
    );
    final src = result?.files.single.path;
    if (src == null) return null;

    final dir = Directory(
        p.join((await getApplicationDocumentsDirectory()).path, 'attachments'));
    await dir.create(recursive: true);
    final dest = p.join(
        dir.path, '${DateTime.now().millisecondsSinceEpoch}_${p.basename(src)}');
    await File(src).copy(dest);

    final draft = Attachment(
      ownerType: ownerType,
      ownerId: ownerId,
      path: dest,
      kind: kind,
      createdAt: DateTime.now(),
    );
    final id = await AppDatabase.instance.insertAttachment(draft);
    return Attachment(
      id: id,
      ownerType: draft.ownerType,
      ownerId: draft.ownerId,
      path: draft.path,
      kind: draft.kind,
      createdAt: draft.createdAt,
    );
  }
}
