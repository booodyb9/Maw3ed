import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_timezone/flutter_timezone.dart';
import 'package:intl/intl.dart';
import 'package:timezone/data/latest_all.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;

import '../data/database.dart';
import '../models/models.dart';

/// معرّفات الإشعارات:
///  - المواعيد: appointmentId * 10 + index  (index من 0 إلى 9)
///  - الأدوية:  1_000_000_000 + medicationId * 10 + index
class NotificationService {
  NotificationService._();
  static final instance = NotificationService._();

  static const _medBase = 1000000000;
  static const _maxSlots = 10;

  final _plugin = FlutterLocalNotificationsPlugin();

  AndroidFlutterLocalNotificationsPlugin? get _android =>
      _plugin.resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin>();

  Future<void> init() async {
    tzdata.initializeTimeZones();
    final name = await FlutterTimezone.getLocalTimezone();
    tz.setLocalLocation(tz.getLocation(name));

    const settings = InitializationSettings(
      android: AndroidInitializationSettings('@mipmap/ic_launcher'),
      iOS: DarwinInitializationSettings(
        requestAlertPermission: false,
        requestBadgePermission: false,
        requestSoundPermission: false,
      ),
    );
    await _plugin.initialize(settings);
  }

  /// الأفضل تستدعيها من شاشة الترحيب بدل أول تشغيل مباشرة.
  Future<void> requestPermissions() async {
    final android = _android;
    await android?.requestNotificationsPermission();
    await android?.requestExactAlarmsPermission();
    await _plugin
        .resolvePlatformSpecificImplementation<
            IOSFlutterLocalNotificationsPlugin>()
        ?.requestPermissions(alert: true, badge: true, sound: true);
  }

  NotificationDetails _details({required bool medication}) {
    final id = medication ? 'medications' : 'appointments';
    final name = medication ? 'تذكير الأدوية' : 'مواعيد العلاج';
    return NotificationDetails(
      android: AndroidNotificationDetails(
        id,
        name,
        channelDescription: name,
        importance: Importance.max,
        priority: Priority.high,
        category: AndroidNotificationCategory.reminder,
      ),
      iOS: const DarwinNotificationDetails(),
    );
  }

  Future<AndroidScheduleMode> _scheduleMode() async {
    final canExact = await _android?.canScheduleExactNotifications() ?? true;
    return canExact
        ? AndroidScheduleMode.exactAllowWhileIdle
        : AndroidScheduleMode.inexactAllowWhileIdle;
  }

  DateTimeComponents? _match(RepeatRule r) {
    switch (r) {
      case RepeatRule.none:
        return null;
      case RepeatRule.daily:
        return DateTimeComponents.time;
      case RepeatRule.weekly:
        return DateTimeComponents.dayOfWeekAndTime;
      case RepeatRule.monthly:
        return DateTimeComponents.dayOfMonthAndTime;
    }
  }

  String _offsetLabel(int minutes) {
    if (minutes <= 0) return 'الآن';
    if (minutes < 60) return 'بعد $minutes دقيقة';
    if (minutes < 1440) return 'بعد ${minutes ~/ 60} ساعة';
    return 'بعد ${minutes ~/ 1440} يوم';
  }

  // ---------------- المواعيد ----------------

  Future<void> scheduleAppointment(Appointment a, String profileName) async {
    await cancelAppointment(a.id!);
    final mode = await _scheduleMode();
    final match = _match(a.repeat);
    final now = tz.TZDateTime.now(tz.local);
    final offsets = a.reminderOffsetsMinutes.take(_maxSlots).toList();

    for (var i = 0; i < offsets.length; i++) {
      final when = tz.TZDateTime.from(
          a.dateTime.subtract(Duration(minutes: offsets[i])), tz.local);
      if (match == null && when.isBefore(now)) continue;

      final timeText = a.repeat == RepeatRule.none
          ? DateFormat('EEEE d MMMM، h:mm a', 'ar').format(a.dateTime)
          : DateFormat('h:mm a', 'ar').format(a.dateTime);
      final doctor = (a.doctor == null || a.doctor!.isEmpty)
          ? ''
          : ' مع ${a.doctor}';

      await _plugin.zonedSchedule(
        a.id! * 10 + i,
        'موعد $profileName ${_offsetLabel(offsets[i])}',
        '${a.title}$doctor — $timeText',
        when,
        _details(medication: false),
        androidScheduleMode: mode,
        uiLocalNotificationDateInterpretation:
            UILocalNotificationDateInterpretation.absoluteTime,
        matchDateTimeComponents: match,
        payload: 'appointment:${a.id}',
      );
    }
  }

  Future<void> cancelAppointment(int appointmentId) async {
    for (var i = 0; i < _maxSlots; i++) {
      await _plugin.cancel(appointmentId * 10 + i);
    }
  }

  // ---------------- الأدوية ----------------

  Future<void> scheduleMedication(Medication m, String profileName) async {
    await cancelMedication(m.id!);

    final now = tz.TZDateTime.now(tz.local);
    final todayStart = DateTime(now.year, now.month, now.day);
    // ملاحظة: التذكير اليومي بيتكرر لحد ما التطبيق يتفتح؛ وقتها
    // rescheduleAll بتلغي الأدوية اللي خلصت مدتها.
    if (m.endDate != null && m.endDate!.isBefore(todayStart)) return;

    final mode = await _scheduleMode();
    final times = m.times.take(_maxSlots).toList();

    for (var i = 0; i < times.length; i++) {
      final t = times[i];
      final today =
          tz.TZDateTime(tz.local, now.year, now.month, now.day, t.hour, t.minute);
      var first = today.isBefore(now) ? today.add(const Duration(days: 1)) : today;
      final startDay = tz.TZDateTime(tz.local, m.startDate.year,
          m.startDate.month, m.startDate.day, t.hour, t.minute);
      if (first.isBefore(startDay)) first = startDay;

      await _plugin.zonedSchedule(
        _medBase + m.id! * 10 + i,
        'موعد دواء $profileName',
        (m.dose == null || m.dose!.isEmpty) ? m.name : '${m.name} — ${m.dose}',
        first,
        _details(medication: true),
        androidScheduleMode: mode,
        uiLocalNotificationDateInterpretation:
            UILocalNotificationDateInterpretation.absoluteTime,
        matchDateTimeComponents: DateTimeComponents.time,
        payload: 'medication:${m.id}',
      );
    }
  }

  Future<void> cancelMedication(int medicationId) async {
    for (var i = 0; i < _maxSlots; i++) {
      await _plugin.cancel(_medBase + medicationId * 10 + i);
    }
  }

  // ---------------- إعادة الجدولة ----------------

  /// بتتنادى عند فتح التطبيق: بتضمن إن كل التذكيرات متسجلة
  /// وبتشيل تذكيرات الأدوية المنتهية.
  Future<void> rescheduleAll(AppDatabase db) async {
    final names = await db.profileNames();
    for (final a in await db.allAppointments()) {
      await scheduleAppointment(a, names[a.profileId] ?? '');
    }
    for (final m in await db.allMedications()) {
      await scheduleMedication(m, names[m.profileId] ?? '');
    }
  }
}
