# مواعيد العلاج

تطبيق Flutter لتنظيم مواعيد العلاج والأدوية، مع تذكيرات ومرفقات وأكتر من ملف شخصي.

## البناء على GitHub (بدون تثبيت Flutter)

1. أنشئ ريبو جديد على GitHub وارفع محتويات هذا المجلد:
   ```bash
   git init
   git add .
   git commit -m "first commit"
   git branch -M main
   git remote add origin https://github.com/<USER>/<REPO>.git
   git push -u origin main
   ```
2. افتح تبويب **Actions** وشوف الـ workflow اسمه **Build Android APK** (بيشتغل تلقائيًا مع كل push على main، أو شغّله بإيدك بـ Run workflow).
3. بعد ما يخلص (حوالي ٥–١٠ دقايق)، ادخل على الـ run ونزّل الملف من **Artifacts**: `mawaeed-ilaj-apk`.
4. فك الضغط وثبّت `app-release.apk` على موبايلك (فعّل التثبيت من مصادر غير معروفة).

### نشر نسخة في Releases
```bash
git tag v0.1.0
git push origin v0.1.0
```
الـ APK هيتضاف تلقائيًا في صفحة Releases.

## إزاي الـ CI بيشتغل
- مجلد `android/` مش موجود في الريبو، فالـ workflow بيولّده بـ `flutter create` ويحافظ على كود `lib/`.
- `tool/patch_android.py` بيضيف صلاحيات الإشعارات وReceivers إعادة الجدولة بعد إعادة التشغيل وإعدادات desugaring واسم التطبيق.
- نسخة Flutter مثبتة على `3.24.5` علشان البناء يكون ثابت.

## ملاحظات
- الـ APK الناتج موقّع بمفتاح debug، يصلح للتجربة والتثبيت الشخصي. للنشر على Google Play هتحتاج keystore خاص بك، قولي وأضيفه عن طريق GitHub Secrets.
- بناء نسخة iOS محتاج macOS runner وحساب Apple Developer، مش مضاف دلوقتي.
- لو أول build فشل، انسخ آخر ١٠٠ سطر من سجل الـ run وابعتهم لي.

## تشغيل محلي (اختياري)
```bash
flutter create --platforms=android,ios .
python3 tool/patch_android.py
flutter pub get
flutter run
```
(لو `flutter create` غيّر `lib/main.dart`، رجّع نسختك.)
