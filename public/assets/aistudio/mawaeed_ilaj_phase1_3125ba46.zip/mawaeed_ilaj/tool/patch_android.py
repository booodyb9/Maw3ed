"""يجهز مشروع أندرويد المولَّد بـ flutter create علشان التذكيرات والخرائط تشتغل.
آمن لو اتشغل أكتر من مرة."""
import pathlib
import re
import sys

ROOT = pathlib.Path("android")
MANIFEST = ROOT / "app/src/main/AndroidManifest.xml"

PERMISSIONS = [
    "android.permission.POST_NOTIFICATIONS",
    "android.permission.RECEIVE_BOOT_COMPLETED",
    "android.permission.SCHEDULE_EXACT_ALARM",
    "android.permission.VIBRATE",
]

QUERY_INTENT = (
    "        <intent>\n"
    '            <action android:name="android.intent.action.VIEW"/>\n'
    '            <data android:scheme="https"/>\n'
    "        </intent>\n"
)

RECEIVERS = """        <receiver android:exported="false"
            android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationReceiver"/>
        <receiver android:exported="false"
            android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationBootReceiver">
            <intent-filter>
                <action android:name="android.intent.action.BOOT_COMPLETED"/>
                <action android:name="android.intent.action.MY_PACKAGE_REPLACED"/>
                <action android:name="android.intent.action.QUICKBOOT_POWERON"/>
                <action android:name="com.htc.intent.action.QUICKBOOT_POWERON"/>
            </intent-filter>
        </receiver>
"""


def patch_manifest():
    if not MANIFEST.exists():
        sys.exit(f"مش لاقي {MANIFEST}")
    m = MANIFEST.read_text(encoding="utf-8")

    if "ScheduledNotificationBootReceiver" in m:
        print("manifest: متظبط بالفعل")
        return

    # 1) الصلاحيات و queries قبل <application>
    block = "".join(
        f'    <uses-permission android:name="{p}"/>\n'
        for p in PERMISSIONS
        if p not in m
    )
    if "<queries>" in m:
        m = m.replace("<queries>", "<queries>\n" + QUERY_INTENT.rstrip("\n"), 1)
    else:
        block += "    <queries>\n" + QUERY_INTENT + "    </queries>\n"

    idx = m.index("<application")
    line_start = m.rfind("\n", 0, idx) + 1
    m = m[:line_start] + block + m[line_start:]

    # 2) الـ receivers قبل </application>
    idx = m.rindex("</application>")
    line_start = m.rfind("\n", 0, idx) + 1
    m = m[:line_start] + RECEIVERS + m[line_start:]

    # 3) اسم التطبيق
    m = re.sub(
        r'(<application[^>]*?android:label=")[^"]*(")',
        r"\1مواعيد العلاج\2",
        m,
        count=1,
        flags=re.S,
    )

    MANIFEST.write_text(m, encoding="utf-8")
    print("manifest: تم التعديل")


def patch_gradle():
    kts = ROOT / "app/build.gradle.kts"
    groovy = ROOT / "app/build.gradle"

    if kts.exists():
        path, is_kts = kts, True
    elif groovy.exists():
        path, is_kts = groovy, False
    else:
        sys.exit("مش لاقي android/app/build.gradle")

    s = path.read_text(encoding="utf-8")
    if "desugar_jdk_libs" in s:
        print("gradle: متظبط بالفعل")
        return

    flag = (
        "isCoreLibraryDesugaringEnabled = true"
        if is_kts
        else "coreLibraryDesugaringEnabled true"
    )
    s, n = re.subn(r"(compileOptions\s*\{)", r"\1\n        " + flag, s, count=1)
    if n == 0:
        sys.exit("مش لاقي compileOptions في ملف gradle")

    dep = (
        'coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.0.4")'
        if is_kts
        else "coreLibraryDesugaring 'com.android.tools:desugar_jdk_libs:2.0.4'"
    )
    s += f"\ndependencies {{\n    {dep}\n}}\n"
    path.write_text(s, encoding="utf-8")
    print(f"gradle: تم التعديل ({path.name})")


patch_manifest()
patch_gradle()
